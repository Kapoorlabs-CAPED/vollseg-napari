# -*- coding: utf-8 -*-
"""
Created on Wed Dec  8 15:54:54 2021

@author: vkapoor
"""

from ._version import __version__
from ._dock_widget import napari_experimental_provide_dock_widget, napari_provide_sample_data
